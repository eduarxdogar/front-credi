import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { AppConfigService } from './services/app-config.service';

describe('AppComponent', () => {
  let service: AppComponent;
  let appConfigServiceSpy: jasmine.SpyObj<AppConfigService>;
  beforeEach(async () => {
    const spy = jasmine.createSpyObj('AppConfigService', ['getConfig']);
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        HttpClientModule,
        NgIdleKeepaliveModule
      ],
      declarations: [
        AppComponent
      ],
      providers: [AppComponent,
        Keepalive,
        {provide: AppConfigService, useValue: spy}
        ]
    }).compileComponents();


    appConfigServiceSpy = TestBed.inject(AppConfigService) as jasmine.SpyObj<AppConfigService>;

    appConfigServiceSpy.getConfig.and.returnValue({
      timeOut:1
    });
    service = TestBed.inject(AppComponent);
  });

  it('should create the app', () => {
    const service: AppComponent = TestBed.get(AppComponent);
    expect(service).toBeTruthy();

/*
   const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
    */
  });

  it(`should have as title 'snp-portal-frontend'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('snp-portal-frontend');
  });  
  
});
