import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UsuarioModel } from '../models/usuario.model';
import { map } from 'rxjs/operators';
import jwt_decode from "jwt-decode";
import { AppConfigService } from './app-config.service';
import { Acceso } from '../models/acceso.model';
import { AppService } from './app.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private url;
  private svAuthPath;
  private clientId;
  private clientSecret;
  private urlLog;

  private _accesos:Acceso;

  userToken: string;
  expires_in: number;

  constructor(  private http: HttpClient,
                private config: AppConfigService,
              private appService: AppService) {

    this.leerToken();
    const {authenticationSSOUri,
           clientId,
           clientSecret,
           backendUrl,
           svLog,
           svAdministracion} = config.getConfig();

                  this.url = authenticationSSOUri;
                  this.urlLog = backendUrl + svAdministracion + svLog;
                  this.clientId = clientId;
                  this.clientSecret = clientSecret;
  }

  public get acceso(): Acceso {
    if(this._accesos != null) {
      return this._accesos;
    } else if (this._accesos == null && sessionStorage.getItem('acceso') != null) {
      this._accesos = JSON.parse(sessionStorage.getItem('acceso')) as Acceso;
    }

    return new Acceso();
  }


  login( usuario: UsuarioModel){

    const headers = {
      'Content-Type': "application/x-www-form-urlencoded"
    }
      const body = new HttpParams()
        .set('username', usuario.username)
        .set('password', usuario.password)
        .set('grant_type', 'password')
        .set('client_id', this.clientId)
        .set('client_secret', this.clientSecret);

    return this.http.post(`${ this.url }`, body, {headers})
    .pipe(
      map( resp =>{
        this.guardarToken( resp['access_token'], resp['expires_in']);
        this.appService.setUserLoggedIn(true);
        this.guardarAccesos();
        this.logLoginSubscribe('login');
        return resp;
      })
    );
  }

  private guardarToken( idToken: string, expires_in: number ){

    this.userToken = idToken;
    localStorage.setItem('token', idToken);

    let hoy = new Date();
    hoy.setSeconds(expires_in);

    localStorage.setItem('expira', hoy.getTime().toString());
  }

  private guardarAccesos() {
    let payload = this.traducirToken();
    this._accesos = new Acceso();
    this._accesos.allowedOrigins = payload["allowed-origins"];
    this._accesos.realm_access = payload.realm_access;
    this._accesos.resource_access = payload.resource_access;
    sessionStorage.setItem('acceso', JSON.stringify(this._accesos));
  }


  leerToken(): any{
    if(localStorage.getItem('token')){
      this.userToken = localStorage.getItem('token');
    }else{
      this.userToken = '';
    }
    return this.userToken;
  }

  logout(){
    this.logLoginSubscribe('logout');
    localStorage.removeItem('token');
    this.appService.setUserLoggedIn(false);

  }

  traducirToken():any{
    try{
      return jwt_decode(this.userToken);
    }catch(Error){
      return null
    }
  }

  estaAutenticado(){
    if(this.userToken.length < 2){
      return false;
    }
    const expira = Number(localStorage.getItem('expira'));
    const expiraDate = new Date();
    expiraDate.setTime(expira);

    if( expiraDate > new Date()){
      return true;
    }else{
      return false;
    }
  }

  tieneRol(role:string): boolean {
    let resp:boolean = false;
    const tokenRole = this.acceso.realm_access? this.acceso.realm_access.roles: '';
    tokenRole.forEach(accessRole => {
      if(role.includes(accessRole)){
        resp = true;
      }
    });
    return resp;
  }

  logLogin(log:string) {
    const headers = {
      'Authorization': 'Bearer ' + localStorage.getItem('token'),

    };
    return this.http.post(`${ this.urlLog }?loginLog=${log}`, null, {headers});
  }

  logLoginSubscribe(log) {
    this.logLogin(log).subscribe(resp =>{
    },(err) =>{
    console.log('error guardar log sesion',err)
  })
  }
}
