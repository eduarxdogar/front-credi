import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EventEmitter, Injectable, Output } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry, tap } from 'rxjs/operators';
import { DesactivarTerminalRequest } from '../models/sv-terminal-desactivar-request.model';
import { TerminalGenericaRequest } from '../models/sv-terminal-generica-request-dto.model';
import { ConsultaTerminalResponse, TerminalGenericaResponse } from '../models/sv-terminal-generica-response-dto.model';
import { AppConfigService } from './app-config.service';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class SvTerminalGenericaService {
  @Output() open: EventEmitter<any> = new EventEmitter();
  private uri;
  private uriOrquestador;

  constructor(
    private http: HttpClient,
    private config: AppConfigService,
    private auth : AuthService
  ) {
    const {backendUrl} = config.getConfig();
    const {svTerminales} = config.getConfig();
    const {svOrquestador} = config.getConfig();
    this.uri = backendUrl + svTerminales;
    this.uriOrquestador = backendUrl + svTerminales + svOrquestador;
  }

  //utilizar esta funcion
  solicitarTerminalGenerica(terminalGenericaRequest: TerminalGenericaRequest): Observable<TerminalGenericaResponse>{
    let uri = this.uriOrquestador;
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer '+ this.auth.leerToken(),
        'Content-Type': 'application/json'
      })
    }
    console.log(uri)

    return this.http.post<TerminalGenericaResponse>(uri, terminalGenericaRequest, httpOptions)
      .pipe( retry(2), tap( d => console.log('consulta Smart Vista Terminal Generica')),
        catchError(this.handleError<any>('consulta Smart Vista Terminal generica'))
      )
  }

  editarTerminal(terminalGenericaRequest: TerminalGenericaRequest): Observable<TerminalGenericaRequest>{
    let uri = this.uriOrquestador
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer '+ this.auth.leerToken(),
        'Content-Type': 'application/json'
      })
    }
    console.log(uri)

    return this.http.put<TerminalGenericaResponse>(uri, terminalGenericaRequest, httpOptions)
      .pipe( retry(2), tap( d => console.log('edición Smart Vista Terminal Generica')),
        catchError(this.handleError<any>('edición Smart Vista Terminal generica'))
      )
  }

  desactivarTerminal( desactivarTerminalRequest: DesactivarTerminalRequest ){
    let uri = this.uriOrquestador + `?terminal=${desactivarTerminalRequest.terminal}&comercio=${desactivarTerminalRequest.comercio}&pasarela=${desactivarTerminalRequest.pasarela}`;
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer '+ this.auth.leerToken(),
        'Content-Type': 'application/json'
      })
    }
    console.log(uri)

    return this.http.delete<TerminalGenericaResponse>(uri, httpOptions)
      .pipe( retry(2), tap( d => console.log('consulta Smart Vista Terminal Generica')),
        catchError(this.handleError<any>('consulta Smart Vista Terminal generica'))
      )
  }

  consultarTerminal( terminalId: string ): Observable<ConsultaTerminalResponse> {
    let uri = this.uri + `/${terminalId}`
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer '+ this.auth.leerToken(),
        'Content-Type': 'application/json'
      })
    }
    console.log(uri)

    return this.http.get<ConsultaTerminalResponse>(uri, httpOptions)
      .pipe( retry(2), tap( d => console.log('consulta de Terminal')),
        catchError(this.handleError<any>('consulta de Terminal'))
      )
  }

  private handleError<T>(operacion, resultado?:T){
    return (error: any): Observable<T> => {
      console.error(error);
      console.log(`${operacion} failed: ${error.message}`);
      return throwError(error)
    }
  }
}
