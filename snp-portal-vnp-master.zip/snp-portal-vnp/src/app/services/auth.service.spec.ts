import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from './app-config.service';

import { AuthService } from './auth.service';
import { Acceso } from '../models/acceso.model';
import { UsuarioModel } from '../models/usuario.model';

describe('AuthService', () => {
  let service: AuthService;
  let appConfigServiceSpy: jasmine.SpyObj<AppConfigService>;
  let controller: HttpTestingController;

  beforeEach(() => {

    const spy = jasmine.createSpyObj('AppConfigService', ['getConfig']);

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,
      RouterTestingModule],
       providers: [AuthService,
       {provide: AppConfigService, useValue: spy}]
    });
    appConfigServiceSpy = TestBed.inject(AppConfigService) as jasmine.SpyObj<AppConfigService>;

    appConfigServiceSpy.getConfig.and.returnValue({
      authenticationSSOUri: 'https://sso-sso-pruebas.apps-pruebas.credibanco.com/auth/realms/pasarelas/protocol/openid-connect/token'
    });
    service = TestBed.inject(AuthService);
    controller = TestBed.inject(HttpTestingController);
  });

  it('should be created spy session storage', () => {
    const store = {
      token: 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5bE51ZGo4c1lBTmJZZXpRTnBCdXotVTZMRE9uRG9YS1dlWGJLTzllTTNzIn0.eyJleHAiOjE2MzQ3NzYxODEsImlhdCI6MTYzNDc0MDE4MSwianRpIjoiYTFkMzYwMGUtMjkwZS00OTZhLTgzOTgtZTZmYTc2ZTlmYTJhIiwiaXNzIjoiaHR0cHM6Ly9zc28tc3NvLXBydWViYXMuYXBwcy1wcnVlYmFzLmNyZWRpYmFuY28uY29tL2F1dGgvcmVhbG1zL3Bhc2FyZWxhcyIsImF1ZCI6WyJyZWFsbS1tYW5hZ2VtZW50IiwiYWNjb3VudCJdLCJzdWIiOiJjMzgwZTBlZC02ZDU1LTQ4NmUtOTc1Ni1iMzM4OTA0N2NjM2UiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJwb3J0YWwtcGFzYXJlbGFzIiwic2Vzc2lvbl9zdGF0ZSI6ImIxMTgwMTA4LTliNzMtNDZlZC1iMTNlLTMyYzM3ZjIyY2JlYiIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsicG9ydGFsLWFkbWluIiwib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7InJlYWxtLW1hbmFnZW1lbnQiOnsicm9sZXMiOlsidmlldy1yZWFsbSIsInZpZXctaWRlbnRpdHktcHJvdmlkZXJzIiwibWFuYWdlLWlkZW50aXR5LXByb3ZpZGVycyIsImltcGVyc29uYXRpb24iLCJyZWFsbS1hZG1pbiIsImNyZWF0ZS1jbGllbnQiLCJtYW5hZ2UtdXNlcnMiLCJxdWVyeS1yZWFsbXMiLCJ2aWV3LWF1dGhvcml6YXRpb24iLCJxdWVyeS1jbGllbnRzIiwicXVlcnktdXNlcnMiLCJtYW5hZ2UtZXZlbnRzIiwibWFuYWdlLXJlYWxtIiwidmlldy1ldmVudHMiLCJ2aWV3LXVzZXJzIiwidmlldy1jbGllbnRzIiwibWFuYWdlLWF1dGhvcml6YXRpb24iLCJtYW5hZ2UtY2xpZW50cyIsInF1ZXJ5LWdyb3VwcyJdfSwiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwic2NvcGUiOiJwcm9maWxlIGVtYWlsIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiTUlHVUVMIEFOR0VMIERBWkEgREFaQSBCVUlUUkFHTyIsInByZWZlcnJlZF91c2VybmFtZSI6Im1kYXphIiwiZ2l2ZW5fbmFtZSI6Ik1JR1VFTCBBTkdFTCBEQVpBIiwiZmFtaWx5X25hbWUiOiJEQVpBIEJVSVRSQUdPIiwiZW1haWwiOiJtaWd1ZWwuZGF6YS1wcm92ZWVkb3JAY3JlZGliYW5jby5jb20ifQ.g1ZkEx8pF24YUeYzBEF62aCTGyVaRFpjPE_BnUVl2J9LKINCdNnAKOtY_pa0xvd3ksuJFjcZy1E57gY6g5Sxa0aGce_VlYFLOrd-FD8TeuocAB123PSeBaxxssTc3RYX8VdVWPB_KiqB5ytrQq15qWSayXPIAm3Ts2AYpwtKjgXTxT4vtRvzDC9wu_Z5l4o6r-oqydersW7TiEh6gitPOlLqHuldslajjALVWKNrCbC0yPskkMtfQ3l-_pD4FbH2mg8I2GTuenYQCf9Qaqt_DMJNlPyUccZDyOVvCt6avVWPXdHN7iJVTylRgVo8bQwaIJwRtRNvvii_REmT5ywwCA',
      'allowed-origins': ''
    };
    spyOn(localStorage, 'getItem').and.callFake((key) => {
      return store[key];
    }); 
    expect(service).toBeTruthy();
  });

  it('should be created null token', () => {
    expect(service).toBeTruthy();
  });


  it('should get acceso', () => {
    const store = {
      token: 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5bE51ZGo4c1lBTmJZZXpRTnBCdXotVTZMRE9uRG9YS1dlWGJLTzllTTNzIn0.eyJleHAiOjE2MzQ3NzYxODEsImlhdCI6MTYzNDc0MDE4MSwianRpIjoiYTFkMzYwMGUtMjkwZS00OTZhLTgzOTgtZTZmYTc2ZTlmYTJhIiwiaXNzIjoiaHR0cHM6Ly9zc28tc3NvLXBydWViYXMuYXBwcy1wcnVlYmFzLmNyZWRpYmFuY28uY29tL2F1dGgvcmVhbG1zL3Bhc2FyZWxhcyIsImF1ZCI6WyJyZWFsbS1tYW5hZ2VtZW50IiwiYWNjb3VudCJdLCJzdWIiOiJjMzgwZTBlZC02ZDU1LTQ4NmUtOTc1Ni1iMzM4OTA0N2NjM2UiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJwb3J0YWwtcGFzYXJlbGFzIiwic2Vzc2lvbl9zdGF0ZSI6ImIxMTgwMTA4LTliNzMtNDZlZC1iMTNlLTMyYzM3ZjIyY2JlYiIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsicG9ydGFsLWFkbWluIiwib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7InJlYWxtLW1hbmFnZW1lbnQiOnsicm9sZXMiOlsidmlldy1yZWFsbSIsInZpZXctaWRlbnRpdHktcHJvdmlkZXJzIiwibWFuYWdlLWlkZW50aXR5LXByb3ZpZGVycyIsImltcGVyc29uYXRpb24iLCJyZWFsbS1hZG1pbiIsImNyZWF0ZS1jbGllbnQiLCJtYW5hZ2UtdXNlcnMiLCJxdWVyeS1yZWFsbXMiLCJ2aWV3LWF1dGhvcml6YXRpb24iLCJxdWVyeS1jbGllbnRzIiwicXVlcnktdXNlcnMiLCJtYW5hZ2UtZXZlbnRzIiwibWFuYWdlLXJlYWxtIiwidmlldy1ldmVudHMiLCJ2aWV3LXVzZXJzIiwidmlldy1jbGllbnRzIiwibWFuYWdlLWF1dGhvcml6YXRpb24iLCJtYW5hZ2UtY2xpZW50cyIsInF1ZXJ5LWdyb3VwcyJdfSwiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwic2NvcGUiOiJwcm9maWxlIGVtYWlsIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiTUlHVUVMIEFOR0VMIERBWkEgREFaQSBCVUlUUkFHTyIsInByZWZlcnJlZF91c2VybmFtZSI6Im1kYXphIiwiZ2l2ZW5fbmFtZSI6Ik1JR1VFTCBBTkdFTCBEQVpBIiwiZmFtaWx5X25hbWUiOiJEQVpBIEJVSVRSQUdPIiwiZW1haWwiOiJtaWd1ZWwuZGF6YS1wcm92ZWVkb3JAY3JlZGliYW5jby5jb20ifQ.g1ZkEx8pF24YUeYzBEF62aCTGyVaRFpjPE_BnUVl2J9LKINCdNnAKOtY_pa0xvd3ksuJFjcZy1E57gY6g5Sxa0aGce_VlYFLOrd-FD8TeuocAB123PSeBaxxssTc3RYX8VdVWPB_KiqB5ytrQq15qWSayXPIAm3Ts2AYpwtKjgXTxT4vtRvzDC9wu_Z5l4o6r-oqydersW7TiEh6gitPOlLqHuldslajjALVWKNrCbC0yPskkMtfQ3l-_pD4FbH2mg8I2GTuenYQCf9Qaqt_DMJNlPyUccZDyOVvCt6avVWPXdHN7iJVTylRgVo8bQwaIJwRtRNvvii_REmT5ywwCA',
      'allowed-origins': ''
    };
    spyOn(localStorage, 'getItem').and.callFake((key) => {
      return store[key];
    }); 
    expect(service.acceso).toBeInstanceOf(Acceso);
  });

  it('should get acceso with access in session storage', () => {
    let token = JSON.stringify({
      allowedOrigins: ['test'],
      realm_access: 'test',
      resource_access: {
        account: {
          roles:['test']
        }
      }
    })
    const store = {
      acceso: token,
      'allowed-origins': ''
    };
    spyOn(sessionStorage, 'getItem').and.callFake((key) => {
      return store[key];
    });   
    expect(service.acceso).toBeInstanceOf(Acceso);
    expect(service.acceso).toBeDefined();
  });

  it('should login', () => {

    let rol = {
        id: 1234,
        nombre: 'admin'
    };
    let usuario: UsuarioModel = {
      id: 1234,
      password: '1234',
      username: 'tester',
      enabled: true,
      roles: [rol],
      uniqueCode: '1234',
      terminalId: '1234',
      fechaCreacion: '10/12/12',
      fechaModificacion: '10/12/12'
    }
    let respLogin:any;

    service.login(usuario).subscribe(
      (resp) => {
        respLogin = resp;
      }
    );
    
    let flushResp = {
      access_token: "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5bE51ZGo4c1lBTmJZZXpRTnBCdXotVTZMRE9uRG9YS1dlWGJLTzllTTNzIn0.eyJleHAiOjE2MzQ3NzYxODEsImlhdCI6MTYzNDc0MDE4MSwianRpIjoiYTFkMzYwMGUtMjkwZS00OTZhLTgzOTgtZTZmYTc2ZTlmYTJhIiwiaXNzIjoiaHR0cHM6Ly9zc28tc3NvLXBydWViYXMuYXBwcy1wcnVlYmFzLmNyZWRpYmFuY28uY29tL2F1dGgvcmVhbG1zL3Bhc2FyZWxhcyIsImF1ZCI6WyJyZWFsbS1tYW5hZ2VtZW50IiwiYWNjb3VudCJdLCJzdWIiOiJjMzgwZTBlZC02ZDU1LTQ4NmUtOTc1Ni1iMzM4OTA0N2NjM2UiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJwb3J0YWwtcGFzYXJlbGFzIiwic2Vzc2lvbl9zdGF0ZSI6ImIxMTgwMTA4LTliNzMtNDZlZC1iMTNlLTMyYzM3ZjIyY2JlYiIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsicG9ydGFsLWFkbWluIiwib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7InJlYWxtLW1hbmFnZW1lbnQiOnsicm9sZXMiOlsidmlldy1yZWFsbSIsInZpZXctaWRlbnRpdHktcHJvdmlkZXJzIiwibWFuYWdlLWlkZW50aXR5LXByb3ZpZGVycyIsImltcGVyc29uYXRpb24iLCJyZWFsbS1hZG1pbiIsImNyZWF0ZS1jbGllbnQiLCJtYW5hZ2UtdXNlcnMiLCJxdWVyeS1yZWFsbXMiLCJ2aWV3LWF1dGhvcml6YXRpb24iLCJxdWVyeS1jbGllbnRzIiwicXVlcnktdXNlcnMiLCJtYW5hZ2UtZXZlbnRzIiwibWFuYWdlLXJlYWxtIiwidmlldy1ldmVudHMiLCJ2aWV3LXVzZXJzIiwidmlldy1jbGllbnRzIiwibWFuYWdlLWF1dGhvcml6YXRpb24iLCJtYW5hZ2UtY2xpZW50cyIsInF1ZXJ5LWdyb3VwcyJdfSwiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwic2NvcGUiOiJwcm9maWxlIGVtYWlsIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiTUlHVUVMIEFOR0VMIERBWkEgREFaQSBCVUlUUkFHTyIsInByZWZlcnJlZF91c2VybmFtZSI6Im1kYXphIiwiZ2l2ZW5fbmFtZSI6Ik1JR1VFTCBBTkdFTCBEQVpBIiwiZmFtaWx5X25hbWUiOiJEQVpBIEJVSVRSQUdPIiwiZW1haWwiOiJtaWd1ZWwuZGF6YS1wcm92ZWVkb3JAY3JlZGliYW5jby5jb20ifQ.g1ZkEx8pF24YUeYzBEF62aCTGyVaRFpjPE_BnUVl2J9LKINCdNnAKOtY_pa0xvd3ksuJFjcZy1E57gY6g5Sxa0aGce_VlYFLOrd-FD8TeuocAB123PSeBaxxssTc3RYX8VdVWPB_KiqB5ytrQq15qWSayXPIAm3Ts2AYpwtKjgXTxT4vtRvzDC9wu_Z5l4o6r-oqydersW7TiEh6gitPOlLqHuldslajjALVWKNrCbC0yPskkMtfQ3l-_pD4FbH2mg8I2GTuenYQCf9Qaqt_DMJNlPyUccZDyOVvCt6avVWPXdHN7iJVTylRgVo8bQwaIJwRtRNvvii_REmT5ywwCA",
      expires_in: 3000
    };
    service.login(usuario);
    const request = controller.expectOne('https://sso-sso-pruebas.apps-pruebas.credibanco.com/auth/realms/pasarelas/protocol/openid-connect/token');
    request.flush(flushResp);

    expect(respLogin).toEqual(flushResp);
    
  })
  

  it('should logout', () => {
    const store = {
      token: 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5bE51ZGo4c1lBTmJZZXpRTnBCdXotVTZMRE9uRG9YS1dlWGJLTzllTTNzIn0.eyJleHAiOjE2MzQ3NzYxODEsImlhdCI6MTYzNDc0MDE4MSwianRpIjoiYTFkMzYwMGUtMjkwZS00OTZhLTgzOTgtZTZmYTc2ZTlmYTJhIiwiaXNzIjoiaHR0cHM6Ly9zc28tc3NvLXBydWViYXMuYXBwcy1wcnVlYmFzLmNyZWRpYmFuY28uY29tL2F1dGgvcmVhbG1zL3Bhc2FyZWxhcyIsImF1ZCI6WyJyZWFsbS1tYW5hZ2VtZW50IiwiYWNjb3VudCJdLCJzdWIiOiJjMzgwZTBlZC02ZDU1LTQ4NmUtOTc1Ni1iMzM4OTA0N2NjM2UiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJwb3J0YWwtcGFzYXJlbGFzIiwic2Vzc2lvbl9zdGF0ZSI6ImIxMTgwMTA4LTliNzMtNDZlZC1iMTNlLTMyYzM3ZjIyY2JlYiIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsicG9ydGFsLWFkbWluIiwib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7InJlYWxtLW1hbmFnZW1lbnQiOnsicm9sZXMiOlsidmlldy1yZWFsbSIsInZpZXctaWRlbnRpdHktcHJvdmlkZXJzIiwibWFuYWdlLWlkZW50aXR5LXByb3ZpZGVycyIsImltcGVyc29uYXRpb24iLCJyZWFsbS1hZG1pbiIsImNyZWF0ZS1jbGllbnQiLCJtYW5hZ2UtdXNlcnMiLCJxdWVyeS1yZWFsbXMiLCJ2aWV3LWF1dGhvcml6YXRpb24iLCJxdWVyeS1jbGllbnRzIiwicXVlcnktdXNlcnMiLCJtYW5hZ2UtZXZlbnRzIiwibWFuYWdlLXJlYWxtIiwidmlldy1ldmVudHMiLCJ2aWV3LXVzZXJzIiwidmlldy1jbGllbnRzIiwibWFuYWdlLWF1dGhvcml6YXRpb24iLCJtYW5hZ2UtY2xpZW50cyIsInF1ZXJ5LWdyb3VwcyJdfSwiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwic2NvcGUiOiJwcm9maWxlIGVtYWlsIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiTUlHVUVMIEFOR0VMIERBWkEgREFaQSBCVUlUUkFHTyIsInByZWZlcnJlZF91c2VybmFtZSI6Im1kYXphIiwiZ2l2ZW5fbmFtZSI6Ik1JR1VFTCBBTkdFTCBEQVpBIiwiZmFtaWx5X25hbWUiOiJEQVpBIEJVSVRSQUdPIiwiZW1haWwiOiJtaWd1ZWwuZGF6YS1wcm92ZWVkb3JAY3JlZGliYW5jby5jb20ifQ.g1ZkEx8pF24YUeYzBEF62aCTGyVaRFpjPE_BnUVl2J9LKINCdNnAKOtY_pa0xvd3ksuJFjcZy1E57gY6g5Sxa0aGce_VlYFLOrd-FD8TeuocAB123PSeBaxxssTc3RYX8VdVWPB_KiqB5ytrQq15qWSayXPIAm3Ts2AYpwtKjgXTxT4vtRvzDC9wu_Z5l4o6r-oqydersW7TiEh6gitPOlLqHuldslajjALVWKNrCbC0yPskkMtfQ3l-_pD4FbH2mg8I2GTuenYQCf9Qaqt_DMJNlPyUccZDyOVvCt6avVWPXdHN7iJVTylRgVo8bQwaIJwRtRNvvii_REmT5ywwCA',
      'allowed-origins': ''
    };
    spyOn(localStorage, 'removeItem').and.callFake(key => {
      return store[key] = undefined;
    });
    service.logout();
    expect(store.token).toBeUndefined();
  });
  
    
  it('should login with wrong token', () => {

    let rol = {
        id: 1234,
        nombre: 'admin'
    };
    let usuario: UsuarioModel = {
      id: 1234,
      password: '1234',
      username: 'tester',
      enabled: true,
      roles: [rol],
      uniqueCode: '1234',
      terminalId: '1234',
      fechaCreacion: '10/12/12',
      fechaModificacion: '10/12/12'
    }
    let respLogin:any;

    service.login(usuario).subscribe(
      (resp) => {
        respLogin = resp;
      }
    );
    
    let flushResp = {
      access_token: "",
      expires_in: 3000
    };
    service.login(usuario);
    const request = controller.expectOne('https://sso-sso-pruebas.apps-pruebas.credibanco.com/auth/realms/pasarelas/protocol/openid-connect/token');
    request.flush(flushResp);

    expect(respLogin).toEqual(undefined);
    
  })

  it('should estaAutenticado', () => {
    const store = {
      expira: '2',
      'allowed-origins': ''
    };
    spyOn(localStorage, 'getItem').and.callFake(key => {
      return store[key];
    });
    //service.userToken = '1234';    
    service.logout();
    expect(service.estaAutenticado()).toBeFalsy();
  });

  it('should tieneRol', () => {
    
    
    let token = JSON.stringify({
      allowedOrigins: ['test'],
      realm_access: {
        roles: [
          "portal-admin",
          "offline_access",
          "uma_authorization"
        ]},
      resource_access: {
        account: {
          roles:['admin']
        }
      }
    });
    const store = {
      expira: '2',
      acceso: token,
      'allowed-origins': ''
    };
    spyOn(localStorage, 'getItem').and.callFake(key => {
      return store[key];
    });
    service.acceso;
   
    expect(service.tieneRol('portal-admin')).toBeTruthy();
  });
  
});
