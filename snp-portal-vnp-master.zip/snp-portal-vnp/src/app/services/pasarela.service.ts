import { Injectable } from '@angular/core';

import { catchError } from 'rxjs/internal/operators';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map } from 'rxjs/operators';

import { AppConfigService } from './app-config.service';
import { Pasarela } from '../models/pasarela.model';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class PasarelaService {

  // pasarela service endpoint
  private endpoint;
  private endpointCSV;

  constructor(private http: HttpClient, private config: AppConfigService) {

    const { backendUrl, svPasarelasPath} = config.getConfig();

    this.endpoint = backendUrl + svPasarelasPath;
    this.endpointCSV ='';
  }

  // error handler
  private handleError(error: HttpErrorResponse): any {

    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred: ', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }

    return throwError('Something bad happened; please try again later.');
  }

  // get token function //TODO: provide general function (service) and validate localStorage token not empty
  private getToken() {

    const headers = {
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    };

    return headers;
  }

  // Pasarela API functions

  // get all pasarelas
  getPasarelas(): Observable<any> {

    const headers = this.getToken();

    return this.http.get<Pasarela>(this.endpoint, {headers}).pipe(
      catchError(this.handleError)
    );
  }

  // create a new pasarela
  savePasarela(newPasarela: Pasarela): Observable<any> {

    const headers = this.getToken();

    return this.http.post<Pasarela>(this.endpoint, newPasarela, {headers}).pipe(
      catchError( e => {
        Swal.fire({
          icon: 'error',
          title: 'Error al crear pasarela',
          text: e.error.message
        })
        return this.handleError
      })
    );
  }

  // update a pasarela
  updatePasarela(editedPasarela: Pasarela): Observable<any> {

    const headers = this.getToken();

    return this.http.put<Pasarela>(this.endpoint, editedPasarela, {headers}).pipe(
      catchError(this.handleError)
    );
  }

  public exportCsv(): Observable<any> {
    const headers = this.getToken();

    return this.http.get<any>(`${this.endpointCSV}`, {headers}).pipe(
      catchError(this.handleError)
    );
  }

}
