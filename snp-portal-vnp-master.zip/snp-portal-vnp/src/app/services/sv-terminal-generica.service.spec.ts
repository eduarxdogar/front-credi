import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { AppConfigService } from './app-config.service';

import { SvTerminalGenericaService } from './sv-terminal-generica.service';
import { HttpEvent } from '@angular/common/http';

describe('SvTerminalGenericaService', () => {
  let service: SvTerminalGenericaService;
  let appConfigServiceSpy: jasmine.SpyObj<AppConfigService>;
  let controller: HttpTestingController;
  
  beforeEach(() => {
    const spy = jasmine.createSpyObj('AppConfigService', ['getConfig']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
       providers: [SvTerminalGenericaService,
       {provide: AppConfigService, useValue: spy}]
    });
    appConfigServiceSpy = TestBed.inject(AppConfigService) as jasmine.SpyObj<AppConfigService>;

    appConfigServiceSpy.getConfig.and.returnValue({
      "backendUrl": "https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com",
      "svTerminales": "/terminales",
      "svOrquestador": "/orquestador"
    });
    service = TestBed.inject(SvTerminalGenericaService);
    controller = TestBed.inject(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be solicitarTerminalGenerica', () => {
    let terminalGenerica = {
      codigoUnico: '123',
      cantidadTerminales: 123,
      tipoComercio: '1',
      funcionalidadesPrincipales:['abc'],
      terminal : 'terminal',
      pasarela: 'pasarela'
    }    

    service.solicitarTerminalGenerica(terminalGenerica).subscribe(event  => { },
    (err) => {
      expect(err).toBeTruthy();
    });        
 

    let mockReq = controller.expectOne('https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/terminales/orquestador')
    mockReq.flush({ errorType: 2,
      errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
      errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
      { status: 404, statusText: 'Bad Request' });    

  });

  it('should be editarTerminal', () => {
    let terminalGenerica = {
      codigoUnico: '123',
      cantidadTerminales: 123,
      tipoComercio: '1',
      funcionalidadesPrincipales:['abc'],
      terminal : 'terminal',
      pasarela: 'pasarela'
    }
    
    service.editarTerminal(terminalGenerica).subscribe(event  => { },
    (err) => {
      expect(err).toBeTruthy();
    });        
 

    let mockReq = controller.expectOne('https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/terminales/orquestador')
    mockReq.flush({ errorType: 2,
      errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
      errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
      { status: 404, statusText: 'Bad Request' });    

  });

  it('should be desactivarTerminal', () => {
    let desactivarTerminal = {
      comercio: 'comercio',
      terminal: 'terminal',
      pasarela: 'pasarela'
    }
    
    service.desactivarTerminal(desactivarTerminal).subscribe(event  => { },
    (err) => {
      expect(err).toBeTruthy();
    });        
 

    let mockReq = controller.expectOne(`https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/terminales/orquestador?terminal=${desactivarTerminal.terminal}&comercio=${desactivarTerminal.comercio}&pasarela=${desactivarTerminal.pasarela}`)
    mockReq.flush({ errorType: 2,
      errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
      errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
      { status: 404, statusText: 'Bad Request' });    

  });

  it('should be consultarTerminal', () => {
    
    service.consultarTerminal('id').subscribe(event  => { },
    (err) => {
      expect(err).toBeTruthy();
    });        
 

    let mockReq = controller.expectOne("https://portal-backend-migracion-pasarelas-dev.apps-pruebas.credibanco.com/terminales/id")
    mockReq.flush({ errorType: 2,
      errorDetails: [{ errorKey: 'errorKey', errorCode: '1001', errorMessage: 'errorMessage' }],
      errorIdentifier: 'cfc78ed9-4e771215efdd64b1' },
      { status: 404, statusText: 'Bad Request' });    

  });

  
});
