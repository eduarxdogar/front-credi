import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-log-auditoria',
  templateUrl: './log-auditoria.component.html'
})
export class LogAuditoriaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
