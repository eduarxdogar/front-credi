import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TerminalGenericaRequest } from 'src/app/models/sv-terminal-generica-request-dto.model';
import { SvTerminalGenericaService } from 'src/app/services/sv-terminal-generica.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-crear-terminal',
  templateUrl: './crear-terminal.component.html',
})
export class CrearTerminalComponent implements OnInit {
  terminalRequest: TerminalGenericaRequest = new TerminalGenericaRequest();
  listaServicios: any[] = [];

  constructor(private svTerminalGenerica: SvTerminalGenericaService) {}

  ngOnInit(): void {
    this.listaServicios = this.poblarListaServicios();
  }

  crearTerminal( form: NgForm ) {



    /* Componente de confirmación de libreria sweetAlert */
    Swal.fire({
      title: '¿Desea guardar los cambios?',
      showDenyButton: true,
      confirmButtonText: `Guardar`,
      denyButtonText: `Cancelar`,
    }).then((result) => {

      if (result.isConfirmed) {
        Swal.fire({
          allowOutsideClick: false,
          icon: 'info',
          text: 'Creando terminal...',
        });
        Swal.showLoading();

        this.listaServicios.forEach((servicios) => {
          if (servicios.enabled) {
            let numService = servicios.nombre;
            this.terminalRequest.funcionalidadesPrincipales.push(numService);
          }
        });

        console.log(this.terminalRequest);
        this.svTerminalGenerica
          .solicitarTerminalGenerica(this.terminalRequest)
          .subscribe(
            (resp) => {
              console.log(resp);
              if(resp.codigoRespuesta=="00"){
                Swal.fire(
                  'Creación exitosa!',
                  `Se ha creado con éxito la terminal con número: ${resp.terminalesCreadas}`,
                  'success'
                );
              }else{
                Swal.fire({
                  icon: 'error',
                  title: 'Error al crear la terminal',
                  text: `${resp.descripcion}`,
                });
              }

            },
            (err) => {
              console.log(err.name);
              Swal.fire({
                icon: 'error',
                title: 'Error al crear la terminal',
                text: err.error.details.substring(err.error.details.indexOf("mensaje")).replaceAll(/["{}]/g,'')
              });
            }
          );
      } else if (result.isDenied) {
      }
    });
  }



  private poblarListaServicios() {
    const listaServicios: any[] = [
      { nombre: 'DCC VISA', codigo: '50170005', enabled: false },
      { nombre: 'DCC MC', codigo: '50170008', enabled: false },
      { nombre: '3D Secure', codigo: '50170009', enabled: false }
    ];
    return listaServicios;
  }

  private ListaServicios() {
    const listaServicios: any[] = [
      { nombre: 'Comercio tradicional', codigo: '50170000', enabled: false },
      {
        nombre: 'Multicomercio tradicional',
        codigo: '50170001',
        enabled: false,
      },
      { nombre: 'Multicomercio agencias', codigo: '50170002', enabled: false },
      {
        nombre: 'Multicomercio servicios públicos',
        codigo: '50170003',
        enabled: false,
      },
      { nombre: 'DCC VISA', codigo: '50170005', enabled: false },
      { nombre: 'DCC MC', codigo: '50170008', enabled: false },
      { nombre: '3D SECURE', codigo: '50170009', enabled: false },
      { nombre: 'API', codigo: '50170010', enabled: false },
      { nombre: 'Link de pagos', codigo: '50170011', enabled: false },
      { nombre: 'Botón de pago', codigo: '50170012', enabled: false },
      { nombre: 'PAGO', codigo: '50170013', enabled: false },
      { nombre: 'Web de pagos', codigo: '50170014', enabled: false },
      { nombre: 'Pago recurrente', codigo: '50170015', enabled: false },
    ];
    return listaServicios;
  }
}
