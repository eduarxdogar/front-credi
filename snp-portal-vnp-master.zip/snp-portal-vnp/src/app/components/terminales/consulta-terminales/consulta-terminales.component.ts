import { Component, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConsultaTerminalResponse } from 'src/app/models/sv-terminal-generica-response-dto.model';
import { SvTerminalGenericaService } from 'src/app/services/sv-terminal-generica.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-consulta-terminales',
  templateUrl: './consulta-terminales.component.html'
})
export class ConsultaTerminalesComponent implements OnInit {

  terminal: ConsultaTerminalResponse;
  numeroTerminal: string;
  atributosIndicadorIcaIvaMap = new Map();
  atributosIndicadorPropinaReferencia = new Map();
  estadoTerminal = new Map();
  servicios = new Map();
  indicadorIac;
  indicadorIva;

  constructor(private servicioConsulta: SvTerminalGenericaService,
              private route: ActivatedRoute,
              private router: Router) { }

  ngOnInit(): void {
    this.route.queryParams
      .subscribe(params => {
        if(params.terminalId===undefined) {
          params.terminalId = "";
        } else {
          this.buscarTerminal(params.terminalId);
        }
      })
    this.llenarIndicadoresMap();
  }

  buscarTerminal(terminalId: string){
    Swal.fire({
      allowOutsideClick: false,
      icon: 'info',
      text: 'Buscando terminal..'
    });
    Swal.showLoading();

    this.servicioConsulta.consultarTerminal(terminalId).subscribe(
      resp => {
        Swal.close()
        console.log(resp)
        if(!resp){
          this.terminal = null
          Swal.fire({
            icon: 'error',
            title: 'Terminal no encontrado',
            text: "Terminal no encontrado"
          });
        }else{
          this.terminal = resp;
          this.indicadorIac = resp.indicadorIca;
          this.indicadorIva = resp.indicadorIva;
          this.terminal.indicadorIca = this.mapearIndicadores(resp.indicadorIca);
          this.terminal.indicadorIva = this.mapearIndicadores(resp.indicadorIva);
          this.terminal.indicadorPropina = this.atributosIndicadorPropinaReferencia.get(resp.indicadorPropina/1);
          this.terminal.indicadorReferencia = this.atributosIndicadorPropinaReferencia.get(resp.indicadorReferencia/1);
          this.terminal.terminalState = this.estadoTerminal.get(resp.terminalState);
          this.terminal.servicios.forEach((value, index)=>{
            this.terminal.servicios[index] = this.servicios.get(value);
          });
        }

      }, (err) => {
        Swal.close()
        Swal.fire({
          icon: 'error',
          title: 'Error en el servicio de consulta',
          text: err.error.message
        });
      }
    );

  }

  editarTerminal(){
    this.router.navigate(['/terminales/editar'], { queryParams: { terminalId: this.terminal.terminalId,
                                                                  indicadorIca: this.indicadorIac,
                                                                  indicadorIva: this.indicadorIva,
                                                                  uniqueCode: this.terminal.uniqueCode,
                                                                  servicios: this.terminal.servicios
                                                                  } });
  }

  mapearIndicadores(codigoIndicador: string){
    return this.atributosIndicadorIcaIvaMap.get(codigoIndicador);
  }

  llenarIndicadoresMap(){
    this.atributosIndicadorIcaIvaMap.set("50115001", "No aplica");
    this.atributosIndicadorIcaIvaMap.set("50115002", "Automático");
    this.atributosIndicadorIcaIvaMap.set("50115003", "Manual");

    this.atributosIndicadorPropinaReferencia.set( 0 , "No");
    this.atributosIndicadorPropinaReferencia.set( 1 , "Si");

    this.estadoTerminal.set("TRMS0001", "Activo");
    this.estadoTerminal.set("TRMS0002", "Inactivo");
    this.estadoTerminal.set("TRMS0009", "Cerrado");

    this.servicios.set("50170000", "Comercio Tradicional")
    this.servicios.set("50170001", "Multicomercio Tradicional");
    this.servicios.set("50170002", "Multicomercio Agencias");
    this.servicios.set("50170003", "Multicomercio Servicios publicos");
    this.servicios.set("50170005", "DCC VISA");
    this.servicios.set("50170006", "Firma Digital");
    this.servicios.set("50170007", "Corresponsal Bancario");
    this.servicios.set("50170008", "DCC MC");
    this.servicios.set("50170009", "3D SECURE");
    this.servicios.set("50170010", "API");
    this.servicios.set("50170011", "LINK DE PAGOS");
    this.servicios.set("50170012", "BOTON DE PAGO");
    this.servicios.set("50170013", "PAGO");
    this.servicios.set("50170014", "WEB DE PAGOS");
    this.servicios.set("50170015", "PAGO RECURRENTE");
    this.servicios.set("50170016", "RECAUDOS");
    this.servicios.set("50170017", "GESTOR DE RECAUDO");
    this.servicios.set("50170018", "MI PAGO");

  }
}
