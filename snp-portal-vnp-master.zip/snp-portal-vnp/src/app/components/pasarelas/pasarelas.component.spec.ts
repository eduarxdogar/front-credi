import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfigService } from 'src/app/services/app-config.service';

import { PasarelasComponent } from './pasarelas.component';

describe('PasarelasComponent', () => {
  let component: PasarelasComponent;
  let fixture: ComponentFixture<PasarelasComponent>;
  let appConfigServiceSpy: jasmine.SpyObj<AppConfigService>;

  beforeEach(async () => {
    const spy = jasmine.createSpyObj('AppConfigService', ['getConfig']);
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule,
      HttpClientTestingModule],
      providers: [PasarelasComponent,
      {provide: AppConfigService, useValue: spy}],
      declarations: [ PasarelasComponent ]
    })
    .compileComponents();

    appConfigServiceSpy = TestBed.inject(AppConfigService) as jasmine.SpyObj<AppConfigService>;

    appConfigServiceSpy.getConfig.and.returnValue({});
    component = TestBed.inject(PasarelasComponent);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PasarelasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
