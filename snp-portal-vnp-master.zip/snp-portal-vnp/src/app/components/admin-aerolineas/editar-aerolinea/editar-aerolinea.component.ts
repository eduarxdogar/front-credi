import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AerolineaModel } from 'src/app/models/aerolineas.model';
import { AerolineasService } from 'src/app/services/aerolineas.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editar-aerolinea',
  templateUrl: './editar-aerolinea.component.html'
})
export class EditarAerolineaComponent implements OnInit {

  aerolinea: AerolineaModel = new AerolineaModel();

  constructor(private activatedRoute: ActivatedRoute,
              private aerolineaService: AerolineasService,
              private router: Router) { }

  ngOnInit(): void {
    this.cargarAerolinea();
  }

  editarAerolinea( form:NgForm ){

    if ( form.invalid ){
      return;
    }


    this.mostrarConfimacion().then((respuesta: boolean) =>{
      if(respuesta){
        Swal.fire({
          allowOutsideClick: false,
          icon: 'info',
          text: 'Editando Aerolinea...',
        });
        Swal.showLoading();
        this.aerolineaService.editarAerolinea( this.aerolinea )
          .subscribe( resp => {
            Swal.fire({        
              icon: 'success',
              title: 'Edición exitosa!',
              text: `Edicion: ${this.aerolinea.name} exitosa`,
              confirmButtonText: 'Continuar'
            }).then((result) => {
              /* Read more about isConfirmed, isDenied below */
              if (result.isConfirmed) {
                this.router.navigateByUrl("/aerolineas");
              }
            })           
        },
        (err) => {
          console.log(err.name);
          Swal.fire({
            icon: 'error',
            title: 'Error al editar la aerolinea',
            text: err.error.details,
          });
        });
      }else{
        Swal.fire({
          icon: 'info',
          title: 'No se guardaron cambios',
          text: 'No se han guardado los cambios',
        })
      }
    });

  }

  cargarAerolinea(): void{
    this.activatedRoute.params.subscribe(params =>{
      let id = params['id']
      if(id){
        this.aerolineaService.obtenerAerolinea(id).subscribe((aerolinea) => {
          this.aerolinea = aerolinea
        })
      }
    })
  }

  private mostrarConfimacion() : Promise<boolean>{
    return Swal.fire({
      title: '¿Desea guardar los cambios realizados?',
      showDenyButton: true,
      confirmButtonText: `Si`,
      denyButtonText: `No`,
    }).then((result) => {
      if (result.isConfirmed) {
        return true;
      } else if (result.isDenied) {
        return false;
      }
    })
  }

}
