import { Component, Input, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TerminalPasarela } from 'src/app/models/terminal-pasarela.model';
import { TerminalPasarelaService } from 'src/app/services/terminal-pasarela.service';
import { saveAs } from 'file-saver';
import Papa from 'papaparse';
import Swal from 'sweetalert2';
import { AuthService } from 'src/app/services/auth.service';
import { AppConfigService } from 'src/app/services/app-config.service';

@Component({
  selector: 'app-detalle-pasarelas',
  templateUrl: './detalle-pasarelas.component.html',
  styleUrls: ['./detalle-pasarelas.component.css']
})
export class DetallePasarelasComponent implements OnInit {



@Input() editableTerminalPasarela: TerminalPasarela = null;
@Input() createdTerminalPasarela: TerminalPasarela[] = null;

  private MAX_NUMBER_REGISTERS_UPLOAD;

  headersCsv: string[] = ["id", "nitComercio", "cuComercio",  "nombreComercio", "numeroTerminal", "nombrePasarela", "activo", "usuarioCreacion", "fechaModificacion", "usuarioModificacion" ];

  fileToUpload: File | null = null;
  errors: any[] = [];
  parsedData: any;

  terminalPasarelas: TerminalPasarela[] = [];
  filtroTerminal: string;
  filtroCu: string;
  filtroPasarela: string;

  accesoEdicion: string;
  filasTerminalEstadoErroneos: number[] = [];

  constructor(private terminalPasarelasService: TerminalPasarelaService,
              private modalService: NgbModal,
              private auth: AuthService,
              private config: AppConfigService) {

  const { asociacionTerminalesEdicion,
    maxNumberUploadRegisters
          } = config.getConfig();
  this.accesoEdicion = asociacionTerminalesEdicion;
  this.MAX_NUMBER_REGISTERS_UPLOAD = maxNumberUploadRegisters;
 }


  ngOnInit(): void {    
    this.getTerminalPasarelas();
  }

  getTerminalPasarelas(): void {
    Swal.showLoading();
    // call the pasarela service
    this.terminalPasarelasService.getTerminalPasarela()
    .subscribe( resp => {
      Swal.close()
      this.terminalPasarelas = resp;
    },

    err => {
       Swal.close()
       console.log("error obteniendo la información", err);
       Swal.fire({icon: 'error', title: 'Error', text: "Error obteniendo la información"});
     });

  }

  // show the form to create a new pasarela
  createForm(content: any): void {

    this.createdTerminalPasarela =[new TerminalPasarela];

    this.modalService.open(content, { size: 'lg' });
  }

  // show a edit form for a pasarela object
  editForm(content: any, numeroTerminal: string): void {

    // reset object to be edited
    this.editableTerminalPasarela = null;

    // search object to edit
    for (const terminalPasarela of this.terminalPasarelas) {
      if (terminalPasarela.numeroTerminal === numeroTerminal) {
        this.editableTerminalPasarela = Object.assign({}, terminalPasarela);
      }
    }

    // validate if pasarela object was found
    if (this.editableTerminalPasarela != null) {
      // show the modal
      this.modalService.open(content);
    } else {
      // alert for object not found
      alert('No se encuentra el objeto solicitado');
    }
  }

  editTerminalPasarela(): void {
    // call the pasarela service (validate on server error)
    this.terminalPasarelasService.updateTerminalPasarela(this.editableTerminalPasarela).subscribe((resp: any) => {

      
      // message indicating that the update was successful
      Swal.fire({        
        icon: 'success',
        title: 'Edicion exitosa',
        text: `Edicion de ${this.editableTerminalPasarela.numeroTerminal} exitosa`,
        confirmButtonText: 'Continuar'
      }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
          // update array calling service
          this.getTerminalPasarelas();
        }
      })     
    },(err) => {
      console.log(err);
      let {details} = err.error

      Swal.fire({        
        icon: 'error',
        title: 'Error al editar la terminal',
        text: details,
        confirmButtonText: 'Continuar'
      }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
          // update array calling service
          this.getTerminalPasarelas();
        }
      })   
    });

    // close the modal
    this.modalService.dismissAll('close');
  }

  // save a new terminal using the terminal service
    createTerminalPasarela(): void {
      // call the pasarela service to save the new object
      Swal.fire({
        allowOutsideClick: false,
        icon: 'info',
        text: 'Procesando...'
      });
      Swal.showLoading();
      this.terminalPasarelasService.saveTerminalPasarela(this.createdTerminalPasarela).subscribe((resp: any) => {
        Swal.close();

         //save file
        //var csv = Papa.unparse(resp);
        const blob = new Blob([resp], { type: 'application/octet-stream' });
        const fileName = 'TerminalesCargadas.csv';
        saveAs(blob, fileName);

        Swal.fire({        
          icon: 'success',
          title: 'Proceso completado',
          text: `validar el archivo para ver las incidencias de carga`,
          confirmButtonText: 'Continuar'
        }).then((result) => {
          /* Read more about isConfirmed, isDenied below */
          if (result.isConfirmed) {
            // update array calling service
            this.getTerminalPasarelas();
          }
        })
      },
      err => {
         Swal.close()
         console.log("error guardando los cambios", err);
         Swal.fire({icon: 'error', title: 'Error', text: "Error guardando los cambios"});
       });

      // close the modal
      this.modalService.dismissAll('close');

    }


  async handleFileInput(files: FileList) {
    var fname = files.item(0).name;
    var re = /(\.csv)$/i;
    if (!re.exec(fname)) {
      Swal.fire({
        icon: 'error',
        title: 'error',
        text: `Solo formato .csv es permitido`,

      });
    } else {
      this.fileToUpload = files.item(0);
      this.parsedData = await this.readCSV();
      this.checkParsedData();
    }
    (<HTMLInputElement>document.getElementById('uploadfile')).value = null;
}

  checkParsedData():void {
      this.errors = this.parsedData.errors;
      if(!this.StateFieldValid()) {
        Swal.fire({
          icon: 'error',
          title: 'el campo estado terminal solo puede ser ACTIVO o INACTIVO',
          text: `error en las siguientes filas: ${this.filasTerminalEstadoErroneos}`,
        });
        this.filasTerminalEstadoErroneos = [];
      }
      else if(this.errors[0]) {
        Swal.fire({
          icon: 'error',
          title: 'error',
          text: `${this.errors[0].message} in row ${this.errors[0].row + 2}`,

        });
      } else if(Object.keys(this.createdTerminalPasarela).length > this.MAX_NUMBER_REGISTERS_UPLOAD) {
        Swal.fire({
          icon: 'error',
          title: 'error',
          text: `maximo numero de registros permitidos es ${this.MAX_NUMBER_REGISTERS_UPLOAD} y se intentan cargar ${Object.keys(this.createdTerminalPasarela).length}`
        });
    } else {
      this.createTerminalPasarela();
      Swal.close();
    }
  }

StateFieldValid():boolean {
  let valid = true;
  this.parsedData.data.forEach((data, index) => {
    if( data.activo && data.activo.toUpperCase()==='ACTIVO') {
      data.activo = true;
    } else if( data.activo && data.activo.toUpperCase()==='INACTIVO') {
      data.activo = false;
    } else {
      valid = false;
      this.filasTerminalEstadoErroneos.push(index+2);
    }
  });
  this.createdTerminalPasarela = valid?this.parsedData.data:null;
  return valid;
}

  //convert csv file to json
  async readCSV():Promise<any>  {

    return new Promise(resolve => {
      Papa.parse(this.fileToUpload, {
       header: true,
       skipEmptyLines: 'greedy',
       transformHeader:function(h, i) {
         const a = ["nitComercio", "cuComercio",  "nombreComercio", "numeroTerminal", "nombrePasarela", "activo"];
         return a[i];
       },
       complete: function(results) {
         resolve(results);
       }
     });
   })
  }


  obtenerTransacciones(buttonType){
    // this.dateToStringMap();
    if(buttonType==="csv"){
      Swal.fire({
        allowOutsideClick: false,
        icon: 'info',
        text: 'Obteniendo el archivo CSV...'
      });
      Swal.showLoading();

      this.terminalPasarelasService.obtenerTerminalCsv()
      .subscribe((data: any) => {
          Swal.close()
          const blob = new Blob([data], { type: 'application/octet-stream' });
          const fileName = 'Plantilla.csv';
          saveAs(blob, fileName);
         },

         err => {
            Swal.close()
            console.log("Servicio de consulta de transacciones CSV", err);
            Swal.fire({icon: 'error', title: 'Error', text: "Error obteniendo el archivo CSV"});
          }
      )
    }
  }

  exportarCsv():void {
    this.terminalPasarelasService.exportCsv()
    .subscribe((data: any) => {
      var dataFiltro = this.filtroExportarCsv(data);
      var dataFiltro = this.removerEstadoGuardado(dataFiltro);
      var csv = Papa.unparse(dataFiltro);
      const blob = new Blob([csv], { type: 'application/octet-stream' });
      const fileName = 'Terminales.csv';
      saveAs(blob, fileName);
    },

    err => {
       Swal.close()
       console.log("Error exportando CSV", err);
       Swal.fire({icon: 'error', title: 'Error', text: "Error obteniendo el archivo"});
     })
  }

  filtroExportarCsv(data:any):any {
    var terminalesFiltradas = data.filter((terminal) => {
  return !(this.filtroCu && terminal.cuComercio && !terminal.cuComercio.includes(this.filtroCu))
   && !(this.filtroTerminal && terminal.numeroTerminal && !terminal.numeroTerminal.includes(this.filtroTerminal))
   && !(this.filtroPasarela && terminal.nombrePasarela && !terminal.nombrePasarela.includes(this.filtroPasarela))
});

return terminalesFiltradas;

  }

  removerEstadoGuardado(data:any):any {
    data.forEach(terminal => {
      delete terminal['estadoGuardado'];
    });
    return data;
  }

    obtenerPlantillaCsv(){
      this.terminalPasarelasService.obtenerTerminalCsv()
      .subscribe((data: any) => {
          Swal.close()
          const blob = new Blob([data], { type: 'application/octet-stream' });
          const fileName = 'Plantilla.csv';
          saveAs(blob, fileName);
        },

        err => {
            console.log("Servicio de generación de plantilla CSV", err);
          }
      )
    }

    tieneRol(accion:string):boolean {
      return this.auth.tieneRol(accion);
    }

}
