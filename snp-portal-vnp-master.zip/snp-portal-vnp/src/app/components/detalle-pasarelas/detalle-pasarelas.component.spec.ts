import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetallePasarelasComponent } from './detalle-pasarelas.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppConfigService } from 'src/app/services/app-config.service';

describe('DetallePasarelasComponent', () => {
  let component: DetallePasarelasComponent;
  let fixture: ComponentFixture<DetallePasarelasComponent>;
  
  let appConfigServiceSpy: jasmine.SpyObj<AppConfigService>;

  beforeEach(async () => {
    const spy = jasmine.createSpyObj('AppConfigService', ['getConfig']);

    await TestBed.configureTestingModule({      
      imports: [HttpClientTestingModule],
      declarations: [ DetallePasarelasComponent ],
      providers: [DetallePasarelasComponent,
        {provide: AppConfigService, useValue: spy}]

    })
    .compileComponents();


    appConfigServiceSpy = TestBed.inject(AppConfigService) as jasmine.SpyObj<AppConfigService>;
    appConfigServiceSpy.getConfig.and.returnValue({});
    component = TestBed.inject(DetallePasarelasComponent);
  });

 

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
