export class AerolineaModel {
  id:number;
  name:string;
  nacional:number;
  uniqueCode:number;
}
