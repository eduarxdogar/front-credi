
export class UsuarioModel {
  id        : number ;
  password  : string ;
  username  : string ;
  enabled   : boolean;
  roles     : Roles[] = [];
  uniqueCode: string ;
  terminalId: string ;
  fechaCreacion: string;
  fechaModificacion: string;
}

export class Roles{
  id        : number;
  nombre    : string;
}
