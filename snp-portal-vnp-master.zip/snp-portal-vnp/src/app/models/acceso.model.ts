export class Acceso {
  allowedOrigins: string[];
  realm_access: any;
  resource_access: Account;
}

export class Account{
account: Roles;
}

export class Roles{
roles: string[];
}
