export class BusquedaUsuario{
  enabled     : string = '';
  username    : string = '';
  uniqueCode  : string = '';
  terminalId  : string = '';
}

export class UsuarioModelDto {
  id            : number ;
  password      : string ;
  username      : string ;
  enabled       : boolean;
  role          : string ;
  uniqueCode    : string ;
  terminalId    : string ;
  fechaCreacion : string ;
  fechaModificacion: string ;
}

